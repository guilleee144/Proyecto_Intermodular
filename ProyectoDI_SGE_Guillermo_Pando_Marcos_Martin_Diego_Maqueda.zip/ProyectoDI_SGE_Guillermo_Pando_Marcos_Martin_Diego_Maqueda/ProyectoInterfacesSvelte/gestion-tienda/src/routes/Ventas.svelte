<script>
    import SalesReport from '../components/Reportes.svelte';
  </script>
  
  <h1>Informes de Ventas</h1>
  <SalesReport />
  