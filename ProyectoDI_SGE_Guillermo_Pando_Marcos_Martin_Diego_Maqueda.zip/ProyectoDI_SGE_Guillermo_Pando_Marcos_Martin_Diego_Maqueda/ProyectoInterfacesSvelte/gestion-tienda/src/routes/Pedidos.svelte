<script>
    import OrderList from '../components/GestionPedidos.svelte';
  </script>
  
  <h1>Registro de Pedidos</h1>
  <OrderList />
  