<script>
    import ProductList from '../components/Inicio.svelte';
  </script>
  
  <h1>Página Principal: Gestión de Productos</h1>
  <ProductList />
  