<script>
    import Inventory from '../components/Inventario.svelte';
  </script>
  
  <h1>Control de Inventario</h1>
  <Inventory />
  