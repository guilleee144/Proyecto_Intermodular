<script>
    import { onMount } from "svelte";
    import * as d3 from "d3";
    import NavBar from "../components/NavBar.svelte";
  
    let reportes = [
      { categoria: "Ventas", total: 50000 },
      { categoria: "Gastos", total: 15000 },
      { categoria: "Inventario", total: 30000 },
      { categoria: "Salarios", total: 20000 }
    ];
  
    let balance = reportes.find(r => r.categoria === "Ventas").total - (reportes.find(r => r.categoria === "Gastos").total + reportes.find(r => r.categoria === "Salarios").total);
    let rentabilidad = ((balance / reportes.find(r => r.categoria === "Ventas").total) * 100).toFixed(2);
  
    onMount(() => {
      drawPieChart();
    });
  
    function drawPieChart() {
      const width = 300, height = 300, radius = Math.min(width, height) / 2;
      const color = d3.scaleOrdinal(["#007bff", "#dc3545", "#ffc107", "#28a745"]);
  
      const svg = d3.select("#pieChart")
        .attr("width", width)
        .attr("height", height)
        .append("g")
        .attr("transform", `translate(${width / 2}, ${height / 2})`);
  
      const pie = d3.pie().value(d => d.total);
      const data_ready = pie(reportes);
  
      const arc = d3.arc()
        .innerRadius(50)
        .outerRadius(radius);
  
      svg.selectAll(".slice")
        .data(data_ready)
        .enter()
        .append("path")
        .attr("d", arc)
        .attr("fill", (d, i) => color(i))
        .style("opacity", 0.85)
        .style("stroke", "white")
        .style("stroke-width", "2px");
  
      // Añadir leyenda
      const legend = d3.select("#legend")
        .selectAll(".legend-item")
        .data(reportes)
        .enter()
        .append("div")
        .attr("class", "legend-item");
  
      legend.append("span")
        .attr("class", "legend-color")
        .style("background", (d, i) => color(i));
  
      legend.append("span")
        .text(d => d.categoria);
    }
  </script>
  
  <main class="dashboard">
    <NavBar />
    <section class="content">
      <h1>📊 Reportes</h1>
      <div class="reportes-grid">
        <div class="chart-container">
          <h3>Distribución de Recursos</h3>
          <svg id="pieChart"></svg>
          <div id="legend" class="legend"></div>
        </div>
        <div class="reportes">
          <h3>Detalle de Reportes</h3>
          {#each reportes as reporte}
            <div class="reporte">
              <span>{reporte.categoria}</span>
              <span>{reporte.total}€</span>
            </div>
          {/each}
        </div>
        <div class="balance-container">
          <h3>Balance General</h3>
          <p class="balance-text">Balance Neto: <strong>{balance}€</strong></p>
          <p class="rentabilidad-text">Rentabilidad: <strong>{rentabilidad}%</strong></p>
        </div>
      </div>
    </section>
  </main>
  
  <style>
    .dashboard {
      display: flex;
      height: 100vh;
      width: 100vw;
      background: #121212;
      color: white;
    }
    .content {
      flex: 1;
      padding: 40px;
      background: #1E1E1E;
      border-radius: 15px;
      margin: 20px;
      text-align: center;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .reportes-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      grid-template-rows: auto auto;
      gap: 20px;
      width: 100%;
      max-width: 900px;
      margin: auto;
    }
    .chart-container, .reportes, .balance-container {
      background: #2C2C2C;
      padding: 20px;
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      align-items: center;
    }
    .chart-container {
      grid-column: span 2;
    }
    .legend {
      display: flex;
      justify-content: center;
      gap: 10px;
      margin-top: 10px;
    }
    .legend-item {
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .legend-color {
      width: 12px;
      height: 12px;
      border-radius: 50%;
      display: inline-block;
    }
    .reportes .reporte {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      border-bottom: 1px solid gray;
      width: 100%;
    }
    .balance-container {
      width: 90;
      text-align: center;
    }
    .balance-text, .rentabilidad-text {
      font-size: 18px;
      font-weight: bold;
      margin: 5px 0;
    }
  </style>
  