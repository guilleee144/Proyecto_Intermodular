<script>
  import { onMount } from "svelte";
  import * as d3 from "d3";
  import NavBar from "../components/NavBar.svelte";

  let salesData = [
    { mes: "Enero", total: 1200 },
    { mes: "Febrero", total: 1800 },
    { mes: "Marzo", total: 1600 },
    { mes: "Abril", total: 2000 },
    { mes: "Mayo", total: 2200 },
    { mes: "Junio", total: 2100 }
  ];

  let productosMasVendidos = [
    { nombre: "Producto A", porcentaje: 35 },
    { nombre: "Producto B", porcentaje: 25 },
    { nombre: "Producto C", porcentaje: 20 },
    { nombre: "Producto D", porcentaje: 10 },
    { nombre: "Producto E", porcentaje: 10 }
  ];

  let mejorProducto = productosMasVendidos[0];
  let peorProducto = productosMasVendidos[productosMasVendidos.length - 1];

  onMount(() => {
    drawBarChart();
    drawLineChart();
  });

  function drawBarChart() {
    const width = 500, height = 300, margin = { top: 20, right: 30, bottom: 50, left: 50 };

    const svg = d3.select("#barChart")
      .attr("width", width)
      .attr("height", height);

    const xScale = d3.scaleBand()
      .domain(salesData.map(d => d.mes))
      .range([margin.left, width - margin.right])
      .padding(0.4);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(salesData, d => d.total)])
      .range([height - margin.bottom, margin.top]);

    svg.append("g")
      .attr("transform", `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(xScale));

    svg.append("g")
      .attr("transform", `translate(${margin.left},0)`)
      .call(d3.axisLeft(yScale));

    svg.selectAll(".bar")
      .data(salesData)
      .enter()
      .append("rect")
      .attr("x", d => xScale(d.mes))
      .attr("y", d => yScale(d.total))
      .attr("height", d => height - margin.bottom - yScale(d.total))
      .attr("width", xScale.bandwidth())
      .attr("fill", "#007bff")
      .attr("rx", 6);
  }
</script>

<main class="dashboard">
  <NavBar />
  <section class="content">
    <h1>📈 Ventas</h1>

    <div class="grid">
      <!-- Gráfica Principal -->
      <div class="chart-card large">
        <h3>Ventas Mensuales</h3>
        <svg id="barChart"></svg>
      </div>

      <!-- Panel de la Derecha -->
      <div class="right-panel">
        <div class="chart-card small">
          <h3>Tendencia de Ventas</h3>
          <svg id="lineChart"></svg>
        </div>

        <!-- Mejor y Peor Producto -->
        <div class="top-bottom">
          <div class="producto-mejor">
            <h3>📈 Mejor Producto</h3>
            <p>{mejorProducto.nombre}</p>
            <p class="percentage">+{mejorProducto.porcentaje}%</p>
          </div>
          <div class="producto-peor">
            <h3>📉 Peor Producto</h3>
            <p>{peorProducto.nombre}</p>
            <p class="percentage">-{peorProducto.porcentaje}%</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Productos Más Vendidos -->
    <div class="productos">
      <h3>Productos Más Vendidos</h3>
      {#each productosMasVendidos as producto}
        <div class="producto">
          <span>{producto.nombre}</span>
          <span class="percentage">+{producto.porcentaje}%</span>
        </div>
      {/each}
    </div>
  </section>
</main>

<style>
  .dashboard {
    display: flex;
    height: 100vh;
    width: 100vw;
    background: #121212;
    color: white;
  }

  .content {
    flex: 1;
    padding: 30px;
    background: #1E1E1E;
    border-radius: 15px;
    margin: 20px;
  }

  .grid {
    display: grid;
    grid-template-columns: 2fr 1fr;
    gap: 20px;
  }

  .chart-card {
    background: #2C2C2C;
    padding: 20px;
    border-radius: 10px;
    text-align: center;
  }

  .top-bottom {
    display: flex;
    justify-content: space-between;
    background: black;
    padding: 20px;
    margin-top: 20px;
    border-radius: 10px;
  }

  .productos .producto {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    border-bottom: 1px solid gray;
  }

  .percentage {
    font-weight: bold;
    color: #28a745;
  }
</style>
