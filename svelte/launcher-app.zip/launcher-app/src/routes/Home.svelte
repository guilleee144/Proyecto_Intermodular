<script>
    import { onMount } from "svelte";
    import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, updateProfile } from "firebase/auth";
    import { getFirestore, doc, setDoc } from "firebase/firestore";
    import { firebaseApp } from "../lib/firebase";
  
    let nombre = "";
    let email = "";
    let password = "";
    let confirmPassword = "";
    let errorMessage = "";
    let successMessage = "";
    let isRegistering = false;
    let isLoading = false;
  
    const auth = getAuth(firebaseApp);
    const db = getFirestore(firebaseApp);
  
    async function handleAuth() {
      isLoading = true;
      errorMessage = "";
      successMessage = "";
  
      try {
        if (isRegistering) {
          if (password !== confirmPassword) {
            throw new Error("Las contraseñas no coinciden");
          }
  
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          const user = userCredential.user;
  
          // Guardar datos del usuario en Firestore
          await setDoc(doc(db, "usuarios", user.uid), {
            nombre: nombre,
            email: email
          });
  
          await updateProfile(user, { displayName: nombre });
  
          successMessage = "Usuario registrado con éxito. Ahora puedes iniciar sesión.";
          isRegistering = false; // Volver a la vista de login
        } else {
          await signInWithEmailAndPassword(auth, email, password);
          window.location.href = "/dashboard"; // Redirigir al Dashboard si el login es correcto
        }
      } catch (error) {
        errorMessage = "Error: " + error.message;
        console.error("Error de autenticación:", error.message);
      }
  
      isLoading = false;
    }
  
    onMount(() => {
      console.log("Home cargado");
    });
  </script>
  
  <main>
    <div class="container">
      <!-- Contenedor de Formularios con Transición -->
      <div class="form-container {isRegistering ? 'switch' : ''}">
        <!-- Formulario de Inicio de Sesión -->
        <div class="login">
          <h2>Iniciar Sesión</h2>
          <input type="email" bind:value={email} placeholder="Correo electrónico" required />
          <input type="password" bind:value={password} placeholder="Contraseña" required />
  
          {#if errorMessage}
            <p class="error">{errorMessage}</p>
          {/if}
  
          <button on:click={handleAuth} disabled={isLoading}>
            {#if isLoading}
              <span class="loader"></span> Procesando...
            {:else}
              Iniciar Sesión
            {/if}
          </button>
  
          <p class="toggle" on:click={() => isRegistering = true}>
            ¿No tienes cuenta? Regístrate
          </p>
        </div>
  
        <!-- Formulario de Registro -->
        <div class="register">
          <h2>Registro de Usuario</h2>
          <input type="text" bind:value={nombre} placeholder="Nombre completo" required />
          <input type="email" bind:value={email} placeholder="Correo electrónico" required />
          <input type="password" bind:value={password} placeholder="Contraseña" required />
          <input type="password" bind:value={confirmPassword} placeholder="Confirmar contraseña" required />
  
          {#if errorMessage}
            <p class="error">{errorMessage}</p>
          {/if}
  
          {#if successMessage}
            <p class="success">{successMessage}</p>
          {/if}
  
          <button on:click={handleAuth} disabled={isLoading}>
            {#if isLoading}
              <span class="loader"></span> Procesando...
            {:else}
              Registrarse
            {/if}
          </button>
  
          <p class="toggle" on:click={() => isRegistering = false}>
            ¿Ya tienes una cuenta? Inicia sesión
          </p>
        </div>
      </div>
  
      <!-- Sección de Bienvenida -->
      <div class="welcome {isRegistering ? 'switch' : ''}">
        <h1>{isRegistering ? "¿No tienes cuenta?" : "Bienvenido a Launcher Empresarial"}</h1>
        <p>{isRegistering ? "Regístrate en la dashboard :)" : "Gestiona tus aplicaciones empresariales de manera eficiente desde un solo lugar."}</p>
      </div>
    </div>
  </main>
  
  <style>
    * {
      box-sizing: border-box;
      font-family: 'Helvetica Neue', sans-serif;
    }
  
    main {
      height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: linear-gradient(to bottom, #f5f5f5, #e0e0e0);
    }
  
    .container {
      display: flex;
      width: 800px;
      height: 500px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      position: relative;
    }
  
    .form-container {
      display: flex;
      width: 50%;
      transition: transform 0.5s ease-in-out;
      position: relative;
    }
  
    .form-container.switch {
      transform: translateX(100%);
    }
  
    .login, .register {
      width: 100%;
      padding: 40px;
      text-align: center;
      position: absolute;
      transition: opacity 0.5s ease-in-out;
      top: 50%;
      transform: translateY(-50%);
    }
  
    .register {
      opacity: 0;
      transform: translateY(-50%) translateX(-100%);
    }
  
    .switch .login {
      opacity: 0;
      transform: translateY(-50%) translateX(100%);
    }
  
    .switch .register {
      opacity: 1;
      transform: translateY(-50%) translateX(0%);
    }
  
    .welcome {
      flex: 1;
      background: black;
      color: white;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      padding: 20px;
      text-align: center;
      transition: transform 0.5s ease-in-out;
    }
  
    .welcome.switch {
      transform: translateX(-100%);
    }
  
    .welcome h1 {
      font-size: 1.8rem;
      margin-bottom: 10px;
    }
  
    .welcome p {
      font-size: 1rem;
      opacity: 0.8;
    }
  
    input {
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      width: 100%;
      background: #f8f8f8;
      margin-bottom: 10px;
    }
  
    input:focus {
      border-color: #000;
      outline: none;
      background: white;
    }
  
    button {
      padding: 12px;
      background: black;
      color: white;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      font-size: 1rem;
    }
  
    button:hover {
      background: #333;
    }
  
    .toggle {
      margin-top: 15px;
      color: #007bff;
      cursor: pointer;
    }
  
    .toggle:hover {
      text-decoration: underline;
    }
  
    .error {
      color: red;
      font-size: 0.9rem;
    }
  
    .success {
      color: green;
      font-size: 0.9rem;
    }
  </style>
  