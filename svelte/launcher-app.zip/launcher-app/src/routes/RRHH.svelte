<script>
    import { onMount } from "svelte";
    import NavBar from "../components/NavBar.svelte";
  
    let empleados = [
      { nombre: "Juan Pérez", puesto: "Gerente", salario: 3000, estado: "Activo" },
      { nombre: "Ana López", puesto: "Desarrollador", salario: 2500, estado: "Activo" },
      { nombre: "Carlos Ramírez", puesto: "Diseñador", salario: 2200, estado: "Activo" },
      { nombre: "Marta Sánchez", puesto: "Recursos Humanos", salario: 2400, estado: "Inactivo" }
    ];
  
    let mostrarFormulario = false;
    let nuevoEmpleado = { nombre: "", puesto: "", salario: 0, estado: "Activo" };
  
    function agregarEmpleado() {
      empleados = [...empleados, { ...nuevoEmpleado }];
      nuevoEmpleado = { nombre: "", puesto: "", salario: 0, estado: "Activo" };
      mostrarFormulario = false;
    }
  
    onMount(() => {
      console.log("Empleados cargados:", empleados);
    });
  </script>
  
  <main class="dashboard">
    <NavBar />
    <section class="content">
      <h1>👥 Recursos Humanos</h1>
      <div class="empleados-container">
        <h3>Lista de Empleados</h3>
        <div class="empleados">
          {#each empleados as empleado}
            <div class="empleado {empleado.estado === 'Inactivo' ? 'inactivo' : ''}">
              <span>{empleado.nombre}</span>
              <span>{empleado.puesto}</span>
              <span>{empleado.salario}€</span>
              <span class="{empleado.estado === 'Activo' ? 'activo' : 'inactivo'}">{empleado.estado}</span>
            </div>
          {/each}
        </div>
      </div>
  
      <button class="btn-toggle" on:click={() => mostrarFormulario = !mostrarFormulario}>
        {mostrarFormulario ? "✖ Cerrar Formulario" : "➕ Añadir Empleado"}
      </button>
  
      {#if mostrarFormulario}
        <div class="modal">
          <div class="form">
            <h3>Agregar Nuevo Empleado</h3>
            <input type="text" bind:value={nuevoEmpleado.nombre} placeholder="Nombre" class="input" />
            <input type="text" bind:value={nuevoEmpleado.puesto} placeholder="Puesto" class="input" />
            <input type="number" bind:value={nuevoEmpleado.salario} placeholder="Salario (€)" class="input" />
            <select bind:value={nuevoEmpleado.estado} class="input">
              <option value="Activo">Activo</option>
              <option value="Inactivo">Inactivo</option>
            </select>
            <button on:click={agregarEmpleado} class="btn">Añadir Empleado</button>
          </div>
        </div>
      {/if}
    </section>
  </main>
  
  <style>
    .dashboard {
      display: flex;
      height: 100vh;
      width: 100vw;
      background: #121212;
      color: white;
    }
  
    .content {
      flex: 1;
      padding: 30px;
      background: #1E1E1E;
      border-radius: 15px;
      margin: 20px;
      width: calc(100% - 250px);
      min-height: 90vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      overflow-y: auto;
    }
  
    .empleados-container {
      width: 100%;
      background: #2A2A2A;
      padding: 15px;
      border-radius: 10px;
    }
  
    .empleados .empleado {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      border-bottom: 1px solid gray;
    }
  
    .btn-toggle {
      background-color: #007bff;
      color: white;
      font-weight: bold;
      border: none;
      cursor: pointer;
      padding: 12px 20px;
      margin: 15px 0;
      border-radius: 8px;
      transition: 0.3s;
      font-size: 16px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
    }
    .btn-toggle:hover {
      background-color: #0056b3;
    }
  
    .modal {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
    }
  
    .form {
      background: #2C2C2C;
      padding: 25px;
      border-radius: 12px;
      display: flex;
      flex-direction: column;
      gap: 15px;
      width: 40%;
      text-align: center;
      box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.5);
    }
    .input {
      padding: 12px;
      border-radius: 6px;
      border: none;
      background: #444;
      color: white;
      outline: none;
      font-size: 16px;
    }
    .btn {
      background-color: #28a745;
      color: white;
      padding: 14px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
      font-size: 16px;
    }
    .btn:hover {
      background-color: #218838;
    }
    .activo {
      color: #28a745;
    }
    .inactivo {
      color: #dc3545;
    }
  </style>
  