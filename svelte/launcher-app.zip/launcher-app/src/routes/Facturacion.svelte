<script>
    import { onMount } from "svelte";
    import * as d3 from "d3";
    import NavBar from "../components/NavBar.svelte";
  
    let facturasData = [
      { mes: "Enero", total: 5000 },
      { mes: "Febrero", total: 7000 },
      { mes: "Marzo", total: 6500 },
      { mes: "Abril", total: 8000 },
      { mes: "Mayo", total: 9000 },
      { mes: "Junio", total: 8700 }
    ];
  
    let facturas = [
      { cliente: "Empresa A", total: 2000, estado: "Pagado", fecha: "2025-02-10", vencimiento: "2025-02-20" },
      { cliente: "Empresa B", total: 3500, estado: "Pendiente", fecha: "2025-01-15", vencimiento: "2025-02-01" },
      { cliente: "Empresa C", total: 1500, estado: "Pagado", fecha: "2025-02-05", vencimiento: "2025-02-15" },
      { cliente: "Empresa D", total: 5000, estado: "Pendiente", fecha: "2025-01-25", vencimiento: "2025-02-10" }
    ];
  
    let mejorCliente = facturas[0];
    let peorCliente = facturas[facturas.length - 1];
  
    onMount(() => {
      drawBarChart();
      drawPieChart();
    });
  
    function drawBarChart() {
      const width = 500, height = 300, margin = { top: 20, right: 30, bottom: 50, left: 50 };
  
      const svg = d3.select("#barChart")
        .attr("width", width)
        .attr("height", height);
  
      const xScale = d3.scaleBand()
        .domain(facturasData.map(d => d.mes))
        .range([margin.left, width - margin.right])
        .padding(0.4);
  
      const yScale = d3.scaleLinear()
        .domain([0, d3.max(facturasData, d => d.total)])
        .range([height - margin.bottom, margin.top]);
  
      svg.append("g")
        .attr("transform", `translate(0,${height - margin.bottom})`)
        .call(d3.axisBottom(xScale));
  
      svg.append("g")
        .attr("transform", `translate(${margin.left},0)`)
        .call(d3.axisLeft(yScale));
  
      svg.selectAll(".bar")
        .data(facturasData)
        .enter()
        .append("rect")
        .attr("x", d => xScale(d.mes))
        .attr("y", d => yScale(d.total))
        .attr("height", d => height - margin.bottom - yScale(d.total))
        .attr("width", xScale.bandwidth())
        .attr("fill", "#ff5733")
        .attr("rx", 6);
    }
  </script>
  
  <main class="dashboard">
    <NavBar />
    <section class="content">
      <h1>📄 Facturación</h1>
  
      <div class="grid">
        <div class="chart-card large">
          <h3>Facturación Mensual</h3>
          <svg id="barChart"></svg>
        </div>
      </div>
  
      <div class="facturas">
        <h3>Lista de Facturas</h3>
        {#each facturas as factura}
          <div class="factura">
            <span>{factura.cliente}</span>
            <span>{factura.total}€</span>
            <span>{factura.fecha}</span>
            <span class="{factura.estado === 'Pagado' ? 'pagado' : 'pendiente'}">{factura.estado}</span>
            <span class="{new Date(factura.vencimiento) < new Date() && factura.estado === 'Pendiente' ? 'vencido' : ''}">{factura.vencimiento}</span>
          </div>
        {/each}
      </div>
    </section>
  </main>
  
  <style>
    .dashboard {
      display: flex;
      height: 100vh;
      width: 100vw;
      background: #121212;
      color: white;
    }
  
    .content {
      flex: 1;
      padding: 30px;
      background: #1E1E1E;
      border-radius: 15px;
      margin: 20px;
    }
  
    .facturas .factura {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      border-bottom: 1px solid gray;
    }
  
    .pagado {
      color: #28a745;
    }
  
    .pendiente {
      color: #dc3545;
    }
  
    .vencido {
      color: #ff0000;
      font-weight: bold;
    }
  </style>
  