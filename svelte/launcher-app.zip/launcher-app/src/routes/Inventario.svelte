<script>
  import { onMount } from "svelte";
  import * as d3 from "d3";
  import NavBar from "../components/NavBar.svelte";

  let productos = [
      { nombre: "Laptop", stock: 10, precio: 1200, categoria: "Electrónica" },
      { nombre: "Teclado", stock: 3, precio: 30, categoria: "Accesorios" },
      { nombre: "Monitor", stock: 5, precio: 200, categoria: "Electrónica" },
      { nombre: "Silla Ergonómica", stock: 7, precio: 150, categoria: "Muebles" }
  ];

  let nuevoProducto = { nombre: "", stock: 0, precio: 0, categoria: "" };
  let mostrarFormulario = false;

  function agregarProducto() {
      productos = [...productos, { ...nuevoProducto }];
      nuevoProducto = { nombre: "", stock: 0, precio: 0, categoria: "" };
      mostrarFormulario = false;
      drawBarChart();
  }

  function drawBarChart() {
      const width = 500, height = 300, margin = { top: 20, right: 30, bottom: 50, left: 50 };
      d3.select("#barChart").selectAll("*").remove();
      const svg = d3.select("#barChart").attr("width", width).attr("height", height);
      const xScale = d3.scaleBand().domain(productos.map(d => d.nombre)).range([margin.left, width - margin.right]).padding(0.4);
      const yScale = d3.scaleLinear().domain([0, d3.max(productos, d => d.stock)]).range([height - margin.bottom, margin.top]);

      svg.append("g").attr("transform", `translate(0,${height - margin.bottom})`).call(d3.axisBottom(xScale));
      svg.append("g").attr("transform", `translate(${margin.left},0)`).call(d3.axisLeft(yScale));

      svg.selectAll(".bar").data(productos).enter().append("rect")
          .attr("x", d => xScale(d.nombre)).attr("y", d => yScale(d.stock))
          .attr("height", d => height - margin.bottom - yScale(d.stock))
          .attr("width", xScale.bandwidth()).attr("fill", "#007bff").attr("rx", 6);
  }

  onMount(() => {
      drawBarChart();
  });
</script>

<main class="dashboard">
  <NavBar />
  <section class="content">
      <h1>📦 Inventario</h1>
      <svg id="barChart"></svg>

      <div class="productos">
          <h3>Lista de Productos</h3>
          {#each productos as producto}
              <div class="producto {producto.stock < 5 ? 'stock-bajo' : ''}">
                  <span>{producto.nombre}</span>
                  <span>{producto.stock} unidades</span>
                  <span>{producto.precio}€</span>
                  <span>{producto.categoria}</span>
              </div>
          {/each}
      </div>

      <div class="center-btn">
          <button class="btn-toggle" on:click={() => mostrarFormulario = !mostrarFormulario}>
              ➕ Añadir Producto
          </button>
      </div>

      {#if mostrarFormulario}
          <div class="form-container">
              <div class="form">
                  <h3>Agregar Nuevo Producto</h3>
                  <input type="text" bind:value={nuevoProducto.nombre} placeholder="Nombre del Producto" class="input" />
                  <input type="number" bind:value={nuevoProducto.stock} placeholder="Cantidad Inicial" class="input" />
                  <input type="number" bind:value={nuevoProducto.precio} placeholder="Precio (€)" class="input" />
                  <input type="text" bind:value={nuevoProducto.categoria} placeholder="Categoría" class="input" />
                  <button on:click={agregarProducto} class="btn">Añadir Producto</button>
              </div>
          </div>
      {/if}
  </section>
</main>

<style>
  .dashboard {
      display: flex;
      height: 100vh;
      width: 100vw;
      background: #121212;
      color: white;
  }
  
  .content {
      flex: 1;
      padding: 30px;
      background: #1E1E1E;
      border-radius: 15px;
      margin: 20px;
  }
  
  .productos .producto {
      display: flex;
      justify-content: space-between;
      padding: 10px;
      border-bottom: 1px solid gray;
  }
  
  .stock-bajo {
      color: red;
  }

  /* Botón centrado */
  .center-btn {
      display: flex;
      justify-content: center;
      margin-top: 20px;
  }

  /* Botón al estilo de la imagen */
  .btn-toggle {
      background-color: #007bff;
      color: white;
      padding: 12px 25px;
      border-radius: 10px;
      font-weight: bold;
      font-size: 18px;
      cursor: pointer;
      border: none;
      display: flex;
      align-items: center;
      gap: 10px;
      transition: all 0.3s ease-in-out;
      box-shadow: 0px 4px 10px rgba(0, 123, 255, 0.4);
  }

  .btn-toggle:hover {
      background-color: #0056b3;
      transform: translateY(-2px);
      box-shadow: 0px 6px 12px rgba(0, 123, 255, 0.6);
  }

  /* Formulario centrado */
  .form-container {
      position: fixed;
      top: 50%;
      left: 60%;
      transform: translate(-50%, -50%);
      width: 40%;
      background: rgba(30, 30, 30, 0.95);
      padding: 25px;
      border-radius: 12px;
      box-shadow: 0px 4px 15px rgba(255, 255, 255, 0.2);
  }

  .form {
      display: flex;
      flex-direction: column;
      gap: 15px;
  }

  .input {
      padding: 12px;
      border-radius: 6px;
      border: none;
      background: #333;
      color: white;
      outline: none;
      font-size: 16px;
  }

  .btn {
      background-color: #28a745;
      color: white;
      padding: 12px;
      border-radius: 8px;
      font-weight: bold;
      cursor: pointer;
      font-size: 16px;
      transition: all 0.3s ease-in-out;
      border: none;
  }

  .btn:hover {
      background-color: #218838;
      transform: translateY(-2px);
      box-shadow: 0px 6px 12px rgba(40, 167, 69, 0.6);
  }
</style>
