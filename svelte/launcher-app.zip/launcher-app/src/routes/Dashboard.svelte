<script>
  import { Router, Link } from "svelte-routing";
  import NavBar from "../components/NavBar.svelte";

  let modulos = [
    { nombre: "Ventas", ruta: "/ventas", icono: "📈" },
    { nombre: "Facturación", ruta: "/facturacion", icono: "📄" },
    { nombre: "Inventario", ruta: "/inventario", icono: "📦" },
    { nombre: "RRHH", ruta: "/rrhh", icono: "👥" },
    { nombre: "Reportes", ruta: "/reportes", icono: "📊" },
    { nombre: "Dashboard", ruta: "/dashboard", icono: "🏠" }
  ];
</script>

<main class="dashboard">
  <NavBar />
  <section class="content">
    <h1>Bienvenido a tu Dashboard</h1>
    <p>Selecciona un módulo para empezar.</p>
    <div class="modulos-grid">
      {#each modulos as modulo}
        <Link to={modulo.ruta} class="modulo">
          <div class="contenedor">
            <div class="contenedor_imagen">
              <div class="imagen">{modulo.icono}</div>
              <div class="texto_imagen"><h2>{modulo.nombre}</h2></div>
            </div>
            <div class="contenedor_texto">
              <div class="texto"><h2>Módulo de {modulo.nombre}</h2></div>
            </div>
          </div>
        </Link>
      {/each}
    </div>
  </section>
</main>

<style>
  .dashboard {
    display: flex;
    height: 100vh;
    width: 100vw;
    background: #121212;
    color: white;
  }

  .content {
    flex: 1;
    padding: 40px;
    border-radius: 15px;
    margin: 20px;
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }

  .modulos-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(3, 1fr);
    gap: 20px;
    margin-top: 20px;
    width: 100%;
    max-width: 800px;
  }

  .modulo {
    text-decoration: none;
    width: 100%;
  }

  .contenedor {
    display: flex;
    border-radius: 25px;
    width: 100%;
    height: 120px;
    background: rgba(44, 62, 80, 0.9);
    box-shadow: 0px 6px 12px rgba(0, 0, 0, 0.3);
    transition: 0.3s;
  }

  .contenedor:hover {
    background: white;
    transform: scale(1.05);
    box-shadow: 0px 8px 16px rgba(255, 255, 255, 0.4);
  }

  .contenedor_imagen {
    width: 35%;
    height: 100%;
    background-color: #2C2C2C;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    border-top-left-radius: 25px;
    border-bottom-left-radius: 25px;
  }

  .imagen {
    font-size: 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    height: 60%;
  }

  .texto_imagen {
    width: 100%;
    height: 40%;
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .texto_imagen h2 {
    font-size: 18px;
    color: white;
    text-decoration: none;
  }

  .contenedor_texto {
    width: 65%;
    height: 100%;
    background-color: #1E1E1E;
    display: flex;
    align-items: center;
    padding-left: 15px;
    border-top-right-radius: 25px;
    border-bottom-right-radius: 25px;
  }

  .texto h2 {
    font-size: 20px;
    color: white;
    text-decoration: none;
  }

  a {
    text-decoration: none;
  }

  a:visited, a:active {
    text-decoration: none;
  }
</style>
