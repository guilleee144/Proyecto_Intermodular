<script>
  import { Router, Route, Link } from "svelte-routing";
  
  // Importar las páginas
  import Home from "./routes/Home.svelte";
  import Dashboard from "./routes/Dashboard.svelte";
  import Ventas from "./routes/Ventas.svelte";
  import Facturacion from "./routes/Facturacion.svelte";
  import Inventario from "./routes/Inventario.svelte";
  import RRHH from "./routes/RRHH.svelte";
  import Reportes from "./routes/Reportes.svelte";

  let mostrarMenu = false;
</script>

<Router>
  <main>
    <Route path="/" component={Home} />
    <Route path="/dashboard" component={Dashboard} />
    <Route path="/ventas" component={Ventas} />
    <Route path="/facturacion" component={Facturacion} />
    <Route path="/inventario" component={Inventario} />
    <Route path="/rrhh" component={RRHH} />
    <Route path="/reportes" component={Reportes} />
  </main>
</Router>