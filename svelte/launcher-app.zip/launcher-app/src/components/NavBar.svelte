<script>
  let services = [
    { name: "Dashboard", icon: "🏠", route: "/dashboard" },
    { name: "Ventas", icon: "📈", route: "/ventas" },
    { name: "Facturación", icon: "🧾", route: "/facturacion" },
    { name: "Inventario", icon: "📦", route: "/inventario" },
    { name: "RRHH", icon: "👥", route: "/rrhh" },
    { name: "Reportes", icon: "📊", route: "/reportes" }
  ];

  function goTo(route) {
    window.location.href = route;
  }
</script>

<aside class="sidebar">
  <h2 class="logo">🚀 Launcher</h2>
  <nav>
    {#each services as service}
      <button class="nav-item" on:click={() => goTo(service.route)}>
        <span class="icon">{service.icon}</span> {service.name}
      </button>
    {/each}
  </nav>
</aside>

<style>
  .sidebar {
    width: 250px;
    background: black;
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
    height: 100vh;
  }

  .logo {
    font-size: 1.8rem;
    font-weight: bold;
    text-align: center;
    margin-bottom: 20px;
    color: white;
  }

  .nav-item {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px;
    background: none;
    border: none;
    color: white;
    font-size: 1rem;
    text-align: left;
    cursor: pointer;
    width: 100%;
    border-radius: 8px;
  }

  .nav-item:hover {
    background: #333;
  }

  .icon {
    font-size: 1.5rem;
  }
</style>
